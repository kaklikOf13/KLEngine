from tkinter import Tk,Canvas,Menu,Toplevel,UNITS,ALL,END,Entry,Button,Label,Scrollbar,Text,FIRST,END,Frame,Listbox,StringVar,OptionMenu
from tkinter.ttk import Notebook,Combobox
from tkinter.filedialog import askopenfilename,asksaveasfilename,askdirectory
import json,shutil,os,math
from uuid import uuid1
from subprocess import Popen,PIPE
from copy import deepcopy
from _thread import start_new_thread
def get_json(path:str):
    f=open(path)
    f.seek(0)
    txt=f.read()
    f.close()
    return json.loads(txt)
"""def place()
    self.canvas.place(relx=0.23,rely=0,relwidth=.55,relheight=1)"""
class Engine:
    def __init__(self) -> None:
        self.root=Tk()
        self.root.title("KLE")
        self.root.geometry("800x600")
        self.select={"select scene":None}
        self.scene_editor=SceneEditor(self.root,Scene(),{})
        self.scene_editor.place(0,0,1,1)
        mmenu=Menu(self.root,tearoff=0,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
        filemenu=Menu(mmenu,tearoff=0,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
        newmenu=Menu(filemenu,tearoff=0,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
        newmenu.add_command(label="Project",command=self.newproject)
        def new_scene():
            self.scene_editor.scene=Scene()
            self.scene_editor.scene.layers.append("1")
            self.select["select scene"]=None
            self.scene_editor.draw()
            self.scene_editor.update_layers()
        newmenu.add_command(label="Scene",command=new_scene)
        newmenu.add_command(label="Object Type",command=lambda:self.new_objectType(""))
        loadmenu=Menu(filemenu,tearoff=0,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
        def load_project():
            d=askdirectory()
            self.load_project(d)
            
        loadmenu.add_command(label="Project",command=load_project)
        def load_scene():
            self.select['select scene']=askopenfilename(defaultextension=".scene",filetypes=[("klengine Scene",".scene")])[:-len(".scene")]
            if isinstance (self.select['select scene'],str):
                try:
                    self.load_scene(self.select['select scene'])
                except:
                    pass
        loadmenu.add_command(label="Scene",command=load_scene)
        def load_object_type():
            src=askopenfilename(defaultextension=".obj",filetypes=[("klengine Scene",".obj")])[:-len(".obj")]
            if not src.endswith(".obj"):
                src+=".obj"
            self.scene_editor.pro["objects"].setdefault(os.path.basename(src)[:-len(".obj")],src)
            self.scene_editor.update_pro()
        loadmenu.add_command(label="Object Type",command=load_object_type)
        savemenu=Menu(filemenu,tearoff=0,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
        def save_scene():
            if self.select['select scene']==None:
                self.select['select scene']=asksaveasfilename(defaultextension=".scene",filetypes=[("klengine Scene",".scene")])[:-len(".scene")]
            if isinstance (self.select['select scene'],str):
                self.save_scene(self.select['select scene'])
        savemenu.add_command(label="Scene",command=save_scene)
        saveasmenu=Menu(filemenu,tearoff=0,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
        def saveas_scene():
            self.select['select scene']=asksaveasfilename(defaultextension=".scene",filetypes=[("klengine Scene",".scene")])[:-len(".scene")]
            if isinstance (self.select['select scene'],str):
                self.save_scene(self.select['select scene'])
        saveasmenu.add_command(label="Scene",command=saveas_scene)
        filemenu.add_cascade(menu=newmenu,label="New")
        filemenu.add_cascade(menu=loadmenu,label="Load")
        filemenu.add_separator()
        filemenu.add_cascade(menu=savemenu,label="Save")
        filemenu.add_cascade(menu=saveasmenu,label="Save As")
        self.go="go"
        mmenu.add_cascade(label="File",menu=filemenu)
        editmenu=Menu(mmenu,tearoff=0,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
        mmenu.add_cascade(label="Edit",menu=editmenu)
        runmenu=Menu(mmenu,tearoff=0,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
        def run_project():
            self.rtp=False
            save_scene()
            try:
                start_new_thread(self.run_scene(),())
            except:
                pass
        runmenu.add_command(label="This Project",command=run_project)
        mmenu.add_cascade(label="Run",menu=runmenu)
        self.root.config(menu=mmenu,background="#000")
        if os.path.isdir("initial project"):
            shutil.rmtree("initial project")
        self.write_project(os.path.dirname(os.path.abspath(__file__))+"/initial project","main")    
    def run_scene(self,scene=None):
        tp=Toplevel(self.root)
        tp.title("run")
        tp.pack_propagate()
        label=Label(tp,text="Running...",font=self.scene_editor.blocks_font,fg="#fff",background="#000")
        label.pack()
        self.rtp=True
        def run():
            cmd=self.go+" run main.go"
            self.retp=Popen(cmd.split(' '),stdout=PIPE)
            self.retp=self.retp.communicate()[0]
            tp.destroy()
            self.rtp=False
        start_new_thread(run,tuple())
        while self.rtp:
            self.root.update()
        tp=Toplevel(self.root,background="#000")
        tp.title("output")
        txt=Text(tp,background="#000",fg="#fff",font=self.scene_editor.blocks_font)
        txt.pack(expand=1,fill="both")
        txt.insert("1.0",self.retp)
        tp.mainloop()
    def load_project(self,path=""):
        os.chdir(path)
        self.scene_editor.pro=get_json("engine/property.json")
        self.load_scene("assets/scene/initial scene")
    def load_scene(self,path=""):
        scene=Scene()
        scene.load(path)
        self.select["select scene"]=path
        self.scene_editor.scene=scene
        self.scene_editor.draw()
        self.scene_editor.update_layers()
    def save_scene(self,path=""):
        if path!=None:
            self.scene_editor.scene.save(path)
            self.select["select scene"]=path
    def newproject(self):
        tp=Toplevel(self.root)
        baseL=Label(tp,text="Base of project")
        baseL.pack()
        baseE=Entry(tp)
        baseE.insert(0,"main")
        baseE.pack()
        pathL=Label(tp,text="Name or Path")
        pathL.pack()
        pathE=Entry(tp)
        pathE.pack()
        def findPath():
            pathE.delete(ALL)
            pathE.insert(0,askdirectory())
        findPathB=Button(tp,text="Find Path",command=findPath)
        findPathB.pack()
        def finish():
            self.write_project(pathE.get(),baseE.get())
            tp.destroy()
        endB=Button(tp,text="Finish",command=finish)
        endB.pack()
        tp.mainloop()
    def write_project(self,name,base):
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
        p=str(name)
        if not p.startswith("/") and not p.startswith("./") and not (p.startswith("c:") or p.startswith("C:")):
            p="projects/"+p
        shutil.copytree("base_of_projects/"+base,p)
        self.load_project(p)
    def new_objectType(self,base="rect"):
        ObjectEditor(self,self.root,self.scene_editor.pro,base)
    def run(self):
        self.scene_editor.run()
        self.root.mainloop()
class ObjectEditor:
    def __init__(self,engine:Engine,dad,pro,base="") -> None:
        self.engine=engine
        self.tp=Toplevel(dad)
        self.tp.geometry("1000x600")
        self.tp.pack_propagate(False)
        self.tp.protocol("WM_DELETE_WINDOW",self.destroy)
        self.src=None
        self.mmenu=Menu(self.tp,tearoff=0,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
        self.filemenu=Menu(self.mmenu,tearoff=0,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
        self.newmenu=Menu(self.filemenu,tearoff=0,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
        self.newmenu.add_command(label="Null",command=lambda:self.new())
        self.rightnb=Notebook(self.tp)
        self.rightnb.place(relx=.65,rely=0,relw=.35,relh=1)
        self.parametersFrame=Frame(self.rightnb,background="#000")
        self.parametersList=[]
        self.parametersEntrys=[]
        self.editordrawFrame=Frame(self.rightnb,background="#000")
        self.editordrawList=[]
        self.editordrawEntrys=[]
        self.rightnb.add(self.parametersFrame,text="parameters")
        self.rightnb.add(self.editordrawFrame,text="draw in editor")
        self.newmenu.add_command(label="Rectangle",command=lambda:self.new("rect"))
        self.filemenu.add_cascade(menu=self.newmenu,label="New")
        def loadobj():
            self.src=askopenfilename(defaultextension=".obj",filetypes=[("klengine Scene",".obj")])[:-len(".obj")]
            try:
                if isinstance (self.src,str):
                    if not self.src.endswith(".obj"):
                        self.src+=".obj"
                    self.obj_pro=get_json(self.src)
                    self.scene_editor.scene=Scene()
                    self.scene_editor.scene.layers=deepcopy(self.obj_pro["layers"])
                    self.scene_editor.scene.objects=deepcopy(self.obj_pro["objects"])
                    self.scene_editor.scene.connections=deepcopy(self.obj_pro["connections"])
                    self.scene_editor.draw()
                    self.update_draws()
                    self.update_parameters()
            except:
                self.src=None
            
        self.filemenu.add_command(label="Load",command=loadobj)
        self.filemenu.add_separator()
        def save():
            if self.src==None:
                self.src=asksaveasfilename(defaultextension=".obj",filetypes=[("klengine Scene",".obj")])[:-len(".obj")]
            try:
                if isinstance (self.src,str):
                    self.save(self.src)
            except:
                self.src=None
        self.filemenu.add_command(label="Save",command=save)
        def saveas():
            self.src=asksaveasfilename(defaultextension=".obj",filetypes=[("klengine Scene",".obj")])[:-len(".obj")]
            try:
                if isinstance (self.src,str):
                    self.save(self.src)
            except:
                self.src=None
        self.filemenu.add_command(label="SaveAs",command=saveas)
        self.mmenu.add_cascade(menu=self.filemenu,label="File")
        self.tp.config(menu=self.mmenu)
        self.scene_editor=SceneEditor(self.tp,Scene(),pro)
        self.scene_editor.place(0,0,0.65,1,nb=False)
        self.base=base
        self.new(self.base)
        self.scene_editor.run()
    def new_parameter(self):
        self.obj_pro["parameters"].setdefault("","")
        self.update_parameters()
    def update_parameters(self):
        for p in self.parametersList:
            p.destroy()
        ei=0
        oldL=len(self.obj_pro["editor draw"])
        for e in self.parametersEntrys:
            if ei>=oldL:
                break
            self.obj_pro["parameters"].pop(e[2])
            self.obj_pro["parameters"].setdefault(e[0].get(),e[1].get())
            
            ei+=1
        self.parametersList=[]
        self.parametersEntrys=[]
        def Delete(p):
            self.obj_pro["parameters"].pop(p)
            self.update_parameters()
        def reDelete(p):
            return lambda:Delete(p)
        for p in self.obj_pro["parameters"]:
            frame=Frame(self.parametersFrame,background="#000",highlightbackground="#fff",highlightthickness=1)
            namelabel=Label(frame,background="#000",foreground="#fff",text="Name")
            namelabel.pack()
            name=Entry(frame,background="#000",foreground="#fff",highlightbackground="#333")
            name.insert(0,p)
            name.pack()
            frame.pack()
            valuelabel=Label(frame,background="#000",foreground="#fff",text="Value")
            valuelabel.pack()
            value=Entry(frame,background="#000",foreground="#fff",highlightbackground="#333")
            value.insert(0,self.obj_pro["parameters"][p])
            value.pack()
            deleteb=Button(frame,background="#000",foreground="#fff",activebackground="#333",text="Delete",command=reDelete(p))
            deleteb.pack()
            self.parametersList.append(frame)
            self.parametersEntrys.append([name,value,p])
        nbtn=Button(self.parametersFrame,background="#000",foreground="#fff",activebackground="#333",text="New Parameter",command=self.new_parameter)
        nbtn.pack()
        self.parametersList.append(nbtn)
    def update_draws(self):
        ei=0
        oldL=len(self.obj_pro["editor draw"])
        for e in self.editordrawEntrys:
            if ei>=oldL:
                break
            try:
                self.obj_pro["editor draw"].pop(0)
                self.obj_pro["editor draw"].append(e.get())
            except:
                pass
            ei+=1
        for d in self.editordrawList:
            d.destroy()
        def Delete(p):
            self.obj_pro["editor draw"].pop(p)
            self.update_draws()
        def reDelete(p):
            return lambda:Delete(p)
        for d in range(len(self.obj_pro["editor draw"])):
            frame=Frame(self.editordrawFrame,background="#000",highlightbackground="#fff",highlightthickness=1)
            entry=Entry(frame,background="#000",foreground="#fff",highlightbackground="#333",width=17)
            entry.insert(0,self.obj_pro["editor draw"][d])
            entry.pack()
            deleteButton=Button(frame,background="#000",foreground="#fff",activebackground="#333",text="Delete",command=reDelete(d))
            deleteButton.pack()
            frame.pack()
            self.editordrawList.append(frame)
            self.editordrawEntrys.append(entry)
        def newDrawCommand():
            if len(self.obj_pro["editor draw"])==0:
                self.obj_pro["editor draw"].append("rect #fff 0 0")
                self.update_draws()
        newDraw=Button(self.editordrawFrame,background="#000",foreground="#fff",activebackground="#333",text="New Draw",command=newDrawCommand)
        newDraw.pack()
        self.editordrawList.append(newDraw)
    def save(self,path:str):
        if not path.endswith(".obj"):
            path+=".obj"
        f=open(path,"w")
        f.seek(0)
        self.update_draws()
        self.update_parameters()
        self.obj_pro["scene"]=self.scene_editor.scene.json()
        f.write(json.dumps(self.obj_pro))
        f.close()
    def new(self,base="rect"):
        self.base=base
        self.src=None
        self.scene_editor.scene=Scene()
        self.scene_editor.default_layer="main"
        self.scene_editor.scene.layers.append("main")
        self.obj_pro={"inputs":{},"outputs":{},"parameters":{},"editor draw":[],"scale":[1,1],"scene":None}
        if base=="rect":
            self.scene_editor.scene.layers=["main"]
            self.scene_editor.scene.objects=[{"parameters": {}, "scale": [1.25, 1], "type": "on update", "layer": "main", "position": [2.4499999999999975, 0.9999999999999993], "bid": "2aec7cb4-9dfd-11ed-af53-d18505b9bfe0"}, {"parameters": {}, "scale": [2, 0.5], "type": "this gameObject", "layer": "main", "position": [-1.5800000000000045, 3.2899999999999965], "bid": "2fd1098e-9dfd-11ed-af53-d18505b9bfe0"}, {"parameters": {}, "scale": [3.15, 0.5], "type": "gameObject get transform", "layer": "main", "position": [0.49999999999999956, 3.309999999999994], "bid": "32bc02b6-9dfd-11ed-af53-d18505b9bfe0"}, {"parameters": {"name": "color"}, "scale": [1.25, 1], "type": "set local", "layer": "main", "position": [3.09, 4.51], "bid": "440c61be-9dfd-11ed-af53-d18505b9bfe0"}, {"parameters": {"value": "#fff"}, "scale": [1, 0.5], "type": "string", "layer": "main", "position": [1.7000000000000008, 4.899999999999999], "bid": "4a1f8bee-9dfd-11ed-af53-d18505b9bfe0"}, {"parameters": {"name": "color"}, "scale": [1.25, 0.5], "type": "get local", "layer": "main", "position": [2.5099999999999887, 2.649999999999999], "bid": "568f2f24-9dfd-11ed-af53-d18505b9bfe0"}, {"parameters": {}, "scale": [1.15, 1], "type": "draw rect", "layer": "main", "position": [4.709999999999991, 2.830000000000003], "bid": "67d0da08-9dfd-11ed-af53-d18505b9bfe0"}, {"parameters": {}, "scale": [1, 1], "type": "is equal", "layer": "main", "position": [0.1400000000000001, 3.900000000000012], "bid": "ce50f22c-a1c7-11ed-87f0-779bd2e88eb3"}, {"parameters": {}, "scale": [1, 0.5], "type": "null", "layer": "main", "position": [-1.2899999999999998, 4.390000000000002], "bid": "f19c16bc-a1c7-11ed-87f0-779bd2e88eb3"}, {"parameters": {"name": "color"}, "scale": [1.25, 0.5], "type": "get local", "layer": "main", "position": [-1.41, 3.8700000000000006], "bid": "fd9dd464-a1c7-11ed-87f0-779bd2e88eb3"}]
            self.scene_editor.scene.connections=[{"input block": "32bc02b6-9dfd-11ed-af53-d18505b9bfe0", "input": "gameObject", "output block": "2fd1098e-9dfd-11ed-af53-d18505b9bfe0", "output": "this GameObject"}, {"input block": "67d0da08-9dfd-11ed-af53-d18505b9bfe0", "input": "before", "output block": "2aec7cb4-9dfd-11ed-af53-d18505b9bfe0", "output": "on update"}, {"input block": "67d0da08-9dfd-11ed-af53-d18505b9bfe0", "input": "color", "output block": "568f2f24-9dfd-11ed-af53-d18505b9bfe0", "output": "value"}, {"input block": "67d0da08-9dfd-11ed-af53-d18505b9bfe0", "input": "transform", "output block": "32bc02b6-9dfd-11ed-af53-d18505b9bfe0", "output": "transform"}, {"input block": "440c61be-9dfd-11ed-af53-d18505b9bfe0", "input": "value", "output block": "4a1f8bee-9dfd-11ed-af53-d18505b9bfe0", "output": "value"}, {"input block": "ce50f22c-a1c7-11ed-87f0-779bd2e88eb3", "input": "b", "output block": "f19c16bc-a1c7-11ed-87f0-779bd2e88eb3", "output": "value"}, {"input block": "ce50f22c-a1c7-11ed-87f0-779bd2e88eb3", "input": "a", "output block": "fd9dd464-a1c7-11ed-87f0-779bd2e88eb3", "output": "value"}, {"input block": "440c61be-9dfd-11ed-af53-d18505b9bfe0", "input": "before", "output block": "ce50f22c-a1c7-11ed-87f0-779bd2e88eb3", "output": "result"}]
            self.obj_pro["editor draw"].append("rect #fff 0 0 ")
        self.scene_editor.draw()
        self.update_parameters()
        self.update_draws()
    def destroy(self):
        self.tp.destroy()
        self.scene_editor=None
class SceneEditor:
    def __init__(self,dad,scene,pro=get_json("base_of_projects/main/engine/property.json")):
        self.root=dad
        self.canvas=Canvas(self.root,background="#222",bd=0,borderwidth=2,highlightthickness=0,relief='ridge')
        self.canvas_press=[False,False,False]
        self.old_mouse_pos=[0,0]
        self.mouse_pos=[0,0]
        self.mouse_rel=[0,0]
        self.cam_rel=[0,0]
        self.old_cam_rel=[0,0]
        self.addomb=[0,0]
        self.imscale=1
        self.delta=1.3
        self.pro=pro
        self.scene=scene
        self.select={"input object":None,"recent add":[],"output object":None,"object move":[],"select object":[],"input":None,"output":None,"input draw":None,"output draw":None}
        self.cam=[0,0]
        self.cmenu=None
        self.rtp=False
        self.retp=None
        self.blocks_font=("data/fonts/Streamed DEMO.otf",15,"bold")
        self.draw_objs=None
        self.collide_box=None
        self.llbmenu=None
        self.leftnb=Notebook()
        self.layersf=Frame(self.leftnb,bg="#000")
        self.layerslb=Listbox(self.layersf,bg="#000",fg="#fff",font=self.blocks_font)
        self.layerslb.pack(expand=1,fill="both")
        self.shift=False
        self.default_layer=None
        def button3_canvas(e):
            self.canvas_press[2]=True
        def button3_release_canvas(e):
            self.canvas_press[2]=False
        def button1_canvas(e):
            if len(self.select["select object"])==0:
                if self.collide_box==None:
                    self.collide_box=[self.mouse_pos[0]+self.cam[0],self.mouse_pos[1]+self.cam[1],self.mouse_pos[0]+self.cam[0],self.mouse_pos[1]+self.cam[1]]
                    self.collide_box.append(self.canvas.create_rectangle(self.collide_box[0],self.collide_box[1],self.collide_box[2],self.collide_box[3],outline="#fff",fill=""))
            if len(self.select["select object"])>0 and not self.shift:
                b=False
                for o in self.select["select object"]:
                    if o in self.select["recent add"]:
                        b=True
                if b:
                    self.select["recent add"]=[]
                    return
                self.select["select object"]=[]
                self.draw()
        def button1_release_canvas(e):
            if len( self.select["object move"])>0:
                self.select["object move"]=[]
                self.remove_bbox2()
            if self.collide_box!=None:
                pos = self.canvas.coords(self.collide_box[4])
                ov=self.canvas.find_overlapping(pos[0],pos[1],pos[2],pos[3])
                if not self.shift:
                    self.select["select object"]=[]
                for o in ov:
                    t=None
                    if o in self.draw_objs["rect"]:
                        t="rect"
                    elif o in self.draw_objs["text"]:
                        t="text"
                    if t!=None:
                        if not self.draw_objs[t][o] in self.select["select object"]:
                            self.select["select object"].append(self.draw_objs[t][o])
                if len(ov)>0:
                    self.draw()
                self.canvas.delete(self.collide_box[4])
                self.collide_box=None
        def esc_canvas(e):
            self.canvas.xview_moveto(0)
            self.canvas.yview_moveto(0)
        def motion(e):
            self.mouse_pos=[e.x,e.y]
        def do_popup(event):
            self.cmenu=Menu(tearoff=False,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
            self.cmenu.add_command(label="Create Object",command=self.add_object_window)
            if len(self.select["select object"])>0:
                self.cmenu.add_separator()
                def duplicate():
                    du=[]
                    for obj in self.select["select object"]:
                        id=self.scene.getId()
                        obj=deepcopy(dict(self.scene.get_Object(obj)))
                        obj["bid"]=id
                        obj["position"]=list(self.addomb)
                        self.scene.objects.append(obj)
                    if len(self.select["object move"]):
                        self.select["object move"]=list(du)
                    self.select["select object"]=list(du)
                    self.draw()
                self.cmenu.add_command(label="Duplicate Objects",command=duplicate)
                self.cmenu.add_separator()
                def delete():
                    for obj in self.select["select object"]:
                        self.scene.deleteBlock(self.select,obj)
                    self.draw()
                    self.select["select object"]=[]
                self.cmenu.add_command(label="Delete Objects",command=delete)
            self.cmenu.add_separator()
            self.cmenu.add_command(label="Reload",command=self.draw)
            try:
                self.addomb=[((self.cam[0]+self.mouse_pos[0])/self.pro["metter size"][0])/self.imscale,((self.cam[1]+self.mouse_pos[1])/self.pro["metter size"][1])/self.imscale]
                self.cmenu.tk_popup(event.x_root, event.y_root)
            finally:
                self.cmenu.grab_release()
        def shiftPress(e):
            self.shift=True
        def shiftRelease(e):
            self.shift=False
        def do_popup2(event):
            self.llbmenu=Menu(tearoff=False,bg="#000",foreground="#fff",activebackground="#333",activeforeground="#fff")
            def Add_Layer():
                try:
                    v=self.get_txt("Layer Name")
                    if v!=None:
                        self.scene.layers.append(v)
                    self.update_layers()
                except:
                    pass
            self.llbmenu.add_command(label="Add Layer",command=Add_Layer)
            if len(self.layerslb.curselection())>0:
                def Delete_Layer():
                    for c in self.layerslb.curselection():
                        self.scene.remove_layer(c,self.select)
                    self.draw()
                    self.update_layers()
                self.llbmenu.add_command(label="Delete Layers",command=Delete_Layer)
            try:
                self.llbmenu.tk_popup(event.x_root, event.y_root)
            finally:
                self.llbmenu.grab_release()
        def button1(e):
            if self.llbmenu!=None:
                self.llbmenu.destroy()
                self.llbmenu=None
            if self.cmenu!=None:
                self.cmenu.destroy()
                self.cmenu=None
        def canvas_wheel(event):
            x=self.canvas.canvasx(event.x)
            y=self.canvas.canvasy(event.y)
            scale = 1.0
            if event.num==5 or event.delta==-120:
                self.imscale/=self.delta
                scale/=self.delta
            if event.num==4 or event.delta==120:
                self.imscale*=self.delta
                scale*=self.delta
            
            self.canvas.scale('all', x, y, scale, scale)
            self.draw()
        self.layerslb.bind("<Button-3>",do_popup2)
        self.root.bind("<Button-1>",button1)
        self.leftnb.add(self.layersf,text="Layers")
        self.root.bind("<Motion>",motion)
        self.root.bind("<KeyPress-Shift_L>",shiftPress)
        self.root.bind("<KeyPress-Shift_R>",shiftPress)
        self.root.bind("<Shift-KeyRelease>",shiftRelease)
        self.canvas.bind("<Button-1>", button1_canvas)
        self.canvas.bind("<Button-2>", do_popup)
        self.canvas.bind("<Button-3>",button3_canvas)
        self.canvas.bind("<ButtonRelease-3>",button3_release_canvas)
        self.canvas.bind("<ButtonRelease-1>",button1_release_canvas)
        self.canvas.bind("<Escape>",esc_canvas)
        self.canvas.bind('<MouseWheel>',canvas_wheel)
        self.canvas.bind('<Button-5>',canvas_wheel)
        self.canvas.bind('<Button-4>',canvas_wheel)
        self.canvas.config(xscrollincrement=1,yscrollincrement=1)
    def get_txt(self,text=""):
        tp=Toplevel(self.root,background="#000")
        label=Label(tp,font=self.blocks_font,fg="#fff",text=text,background="#000")
        label.pack()
        entry=Entry(tp,fg="#fff",bg="#000")
        entry.pack()
        self.retp=None
        self.rtp=True
        def Exec():
            self.retp=entry.get()
            self.rtp=False
        def Exit():
            pass
        tp.protocol("WM_DELETE_WINDOW",Exit)
        button=Button(tp,text="Enter",fg="#fff",bg="#000",command=Exec)
        button.pack()
        tp.pack_slaves()
        while self.rtp:
            self.root.update()
        tp.destroy()
        return self.retp
    def update_pro(self):
        f=open("engine/property.json","w")
        f.seek(0)
        f.write(json.dumps(self.pro))
        f.close()
    def update_layers(self):
        self.layerslb.delete(0,END)
        for l in self.scene.layers:
            self.layerslb.insert(END,l)
    def place(self,x=0,y=0,w=1,h=1,nb=True):
        if nb:
            self.canvas.place(relx=0.23+x,rely=0+y,relwidth=.55*w,relheight=1*h)
            self.leftnb.place(relx=.78+x,rely=0+y,relwidth=0.23*w,relheight=1*h)
            self.update_layers()
        else:
            self.canvas.place(relx=x,rely=y,relwidth=w,relheight=h)
    def run(self):
        self.mouse_rel=[self.old_mouse_pos[0]-self.mouse_pos[0],self.old_mouse_pos[1]-self.mouse_pos[1]]
        self.cam_rel=[self.old_cam_rel[0]-(self.mouse_pos[0]+self.cam[0]),self.old_cam_rel[1]-(self.mouse_pos[1]+self.cam[1])]
        self.old_mouse_pos=list(self.mouse_pos)
        self.old_cam_rel=[(self.mouse_pos[0]+self.cam[0]),(self.mouse_pos[1]+self.cam[1])]
        if self.canvas_press[2]:
            x=-math.ceil(self.mouse_rel[0]/2)
            y=-math.ceil(self.mouse_rel[1]/2)
            self.canvas.xview_scroll(x,UNITS)
            self.canvas.yview_scroll(y,UNITS)
            self.cam[0]+=x
            self.cam[1]+=y
        for obj in self.select["object move"]:
            o=self.scene.get_Object2(obj)
            self.scene.objects[o]["position"][0]-=(self.cam_rel[0]/self.pro["metter size"][0])/self.imscale
            self.scene.objects[o]["position"][1]-=(self.cam_rel[1]/self.pro["metter size"][1])/self.imscale
        if self.collide_box!=None:
            self.collide_box[2],self.collide_box[3]=self.mouse_pos[0]+self.cam[0],self.mouse_pos[1]+self.cam[1]
            self.canvas.coords(self.collide_box[4],self.collide_box[0],self.collide_box[1],self.collide_box[2],self.collide_box[3])
        objs_u=self.scene.update()
        if len(objs_u["move"])>0:
            self.draw()
        self.root.after(1,self.run)
    def remove_bbox1(self):
        self.canvas.delete("bbox_select1")
    def remove_bbox2(self):
        self.canvas.delete("bbox_select2")
    def add_object_window(self):
        tp=Toplevel(self.root,background="#000")
        tp.grid()
        typeL=Label(tp,text="Type",fg="#fff",background="#000")
        typeL.pack()
        typeE=Entry(tp,name="type",fg="#fff",background="#000")
        typeE.pack()
        def FindType():
            v=self.find_object_type(tp)
            if isinstance(v,str):
                typeE.delete(0,END)
                typeE.insert(0,v)
        findTypeB=Button(tp,text="Find Type",command=FindType,fg="#fff",bg="#000")
        findTypeB.pack()
        if self.default_layer==None:
            layerL=Label(tp,text="Layer",fg="#fff",background="#000")
            layerL.pack()
            layerE=Entry(tp,name="layer",fg="#fff",bg="#000")
            layerE.pack()
        def Enter():
            l=self.default_layer
            if self.default_layer==None:
                l=layerE.get()
            self.scene.add_object(l,list(self.addomb),typeE.get(),self.pro)
            self.draw()
            tp.destroy()
        enterB=Button(tp,text="Enter",command=Enter,fg="#fff",bg="#000")
        enterB.pack()
        tp.mainloop()
    def find_object_type(self,tpM)->str:
        y=.2
        x=1.4
        tp=Toplevel(tpM)
        tp.grid()
        canvas=Canvas(tp,bg="#222")
        scroll=Scrollbar(tp,orient="vertical",command=canvas.yview,activebackground="#222",background="#222",highlightbackground="#000")
        scroll.pack(fill="y",side="right")
        scroll2=Scrollbar(tp,orient="horizontal",command=canvas.xview,activebackground="#222",background="#222",highlightbackground="#000")
        scroll2.pack(fill="x",side="bottom")
        def canvas_button_4(event):
            canvas.yview_scroll(-1, "units")
        def canvas_button_5(event):
            canvas.yview_scroll(1, "units")
        canvas.pack(expand=1,fill="both")
        canvas.configure(yscrollcommand=scroll.set,xscrollcommand=scroll2.set)
        canvas.bind("<Button-4>", canvas_button_4)
        canvas.bind("<Button-5>", canvas_button_5)
        self.rtp=True
        self.retp=None
        def Exit():
            pass
        tp.protocol("WM_DELETE_WINDOW",Exit)
        def click(e,obj):
            self.retp=str(obj)
            self.rtp=False
            tp.destroy()
        def lReBlock(obj):
            return lambda e:click(e,obj)
        for ob in self.pro["compiled objects orden"]:
            obj=self.pro["compiled objects"][ob]
            scale=obj["scale"]
            for inpt in obj["inputs"]:
                pos2=[x,y]
                pos3=list(pos2)
                anchor="nw"
                if obj["inputs"][inpt]["dire"]==0:
                    pos2[1]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]-0.1,pos2[1]+0.05]
                    anchor="ne"
                elif obj["inputs"][inpt]["dire"]==1:
                    pos2[0]+=obj["scale"][0]
                    pos2[1]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.05]
                elif obj["inputs"][inpt]["dire"]==2:
                    pos2[0]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.15,pos2[1]-0.1]
                    anchor="sw"
                elif obj["inputs"][inpt]["dire"]==3:
                    pos2[1]+=obj["scale"][1]
                    pos2[0]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.1]
                color="#fff"
                if obj["inputs"][inpt]["accept types"]!=None:
                    if len(obj["inputs"][inpt]["accept types"])>0:
                        color=self.pro["types"][obj["inputs"][inpt]["accept types"][0]]["color"]
                o=canvas.create_oval((pos2[0]*100)-13,(pos2[1]*100)-13,(pos2[0]*100)+13,(pos2[1]*100)+10,width=3,fill=color)
                canvas.create_text((pos3[0]*100),(pos3[1]*100),font=self.blocks_font,fill="#000",text=inpt,anchor=anchor)
            for output in obj["outputs"]:
                pos2=[x,y]
                pos3=list(pos2)
                anchor="nw"
                if obj["outputs"][output]["dire"]==0:
                    pos2[1]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]-0.1,pos2[1]+0.05]
                    anchor="ne"
                elif obj["outputs"][output]["dire"]==1:
                    pos2[0]+=obj["scale"][0]
                    pos2[1]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.05]
                elif obj["outputs"][output]["dire"]==2:
                    pos2[0]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.15,pos2[1]-0.1]
                    anchor="sw"
                elif obj["outputs"][output]["dire"]==3:
                    pos2[1]+=obj["scale"][1]
                    pos2[0]+=0.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.1]
                color="#fff"
                color="#fff"
                if obj["outputs"][output]["accept types"]!=None:
                    if len(obj["outputs"][output]["accept types"])>0:
                        color=self.pro["types"][obj["outputs"][output]["accept types"][0]]["color"]
                o=canvas.create_oval((pos2[0]*100)-13,(pos2[1]*100)-13,(pos2[0]*100)+13,(pos2[1]*100)+13,width=3,fill=color)
                canvas.create_text((pos3[0]*100),(pos3[1]*100),font=self.blocks_font,fill="#000",text=output,anchor=anchor)
            for code in obj["editor draw"]:
                code=str(code)
                c=code.split(" ")

                if c[0]=="rect":
                    borderradius=0
                    width=3
                    outline="#000"
                    if len(c)>=3:
                        borderradius=float(c[2])
                    if len(c)>=4:
                        width=float(c[3])
                    if len(c)>=5:
                        outline=c[4]
                    o=canvas.create_polygon(round_rect(x*100,y*100,(scale[0]*100),(scale[1]*100),borderradius),fill=c[1],smooth=True,width=width,outline=outline)
                    canvas.tag_bind(o,"<Button-1>",lReBlock(ob))
                    
                if c[0]=="text":
                    o=canvas.create_text((scale[0]*float(c[1])+x)*100,(scale[1]*float(c[2])+y)*100,text=code[code.find("text:")+len("text:"):],anchor="center" if "center" in code[:code.find("text:")+len("text:")] else "w",font=self.blocks_font)
                    canvas.tag_bind(o,"<Button-1>",lReBlock(ob))
            y+=0.6+scale[1]
        for ob in self.pro["objects"]:
            obj=get_json(self.pro["objects"][ob])
            scale=obj["scale"]
            for inpt in obj["inputs"]:
                pos2=[x,y]
                pos3=list(pos2)
                anchor="nw"
                if obj["inputs"][inpt]["dire"]==0:
                    pos2[1]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]-0.1,pos2[1]+0.05]
                    anchor="ne"
                elif obj["inputs"][inpt]["dire"]==1:
                    pos2[0]+=obj["scale"][0]
                    pos2[1]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.05]
                elif obj["inputs"][inpt]["dire"]==2:
                    pos2[0]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.15,pos2[1]-0.1]
                    anchor="sw"
                elif obj["inputs"][inpt]["dire"]==3:
                    pos2[1]+=obj["scale"][1]
                    pos2[0]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.1]
                color="#fff"
                if obj["inputs"][inpt]["accept types"]!=None:
                    if len(obj["inputs"][inpt]["accept types"])>0:
                        color=self.pro["types"][obj["inputs"][inpt]["accept types"][0]]["color"]
                o=canvas.create_oval((pos2[0]*100)-13,(pos2[1]*100)-13,(pos2[0]*100)+13,(pos2[1]*100)+10,width=3,fill=color)
                canvas.create_text((pos3[0]*100),(pos3[1]*100),font=self.blocks_font,fill="#000",text=inpt,anchor=anchor)
            for output in obj["outputs"]:
                pos2=[x,y]
                pos3=list(pos2)
                anchor="nw"
                if obj["outputs"][output]["dire"]==0:
                    pos2[1]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]-0.1,pos2[1]+0.05]
                    anchor="ne"
                elif obj["outputs"][output]["dire"]==1:
                    pos2[0]+=obj["scale"][0]
                    pos2[1]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.05]
                elif obj["outputs"][output]["dire"]==2:
                    pos2[0]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.15,pos2[1]-0.1]
                    anchor="sw"
                elif obj["outputs"][output]["dire"]==3:
                    pos2[1]+=obj["scale"][1]
                    pos2[0]+=0.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.1]
                color="#fff"
                color="#fff"
                if obj["outputs"][output]["accept types"]!=None:
                    if len(obj["outputs"][output]["accept types"])>0:
                        color=self.pro["types"][obj["outputs"][output]["accept types"][0]]["color"]
                o=canvas.create_oval((pos2[0]*100)-13,(pos2[1]*100)-13,(pos2[0]*100)+13,(pos2[1]*100)+13,width=3,fill=color)
                canvas.create_text((pos3[0]*100),(pos3[1]*100),font=self.blocks_font,fill="#000",text=output,anchor=anchor)
            for code in obj["editor draw"]:
                code=str(code)
                c=code.split(" ")
                try:
                    if c[0]=="rect":
                        borderradius=0
                        width=3
                        outline="#000"
                        if len(c)>=3:
                            borderradius=float(c[2])
                        if len(c)>=4:
                            width=float(c[3])
                        if len(c)>=5:
                            outline=c[4]
                        o=canvas.create_polygon(round_rect(x*100,y*100,(scale[0]*100),(scale[1]*100),borderradius),fill=c[1],smooth=True,width=width,outline=outline)
                        canvas.tag_bind(o,"<Button-1>",lReBlock(ob))
                        
                    if c[0]=="text":
                        o=canvas.create_text((scale[0]*float(c[1])+x)*100,(scale[1]*float(c[2])+y)*100,text=code[code.find("text:")+len("text:"):],anchor="center" if "center" in code[:code.find("text:")+len("text:")] else "w",font=self.blocks_font)
                        canvas.tag_bind(o,"<Button-1>",lReBlock(ob))
                except:
                    pass
            y+=0.4+scale[1]
        canvas.config(scrollregion=canvas.bbox("all"))
        tp.pack_propagate()
        while self.rtp:
            self.root.update()
        return self.retp
    def draw(self):
        ok=False
        for o in list(self.pro["objects"]):
            if not os.path.isfile(self.pro["objects"][o]):
                self.pro["objects"].pop(o)
                ok=True
        if ok:
            self.update_pro()
        self.draw_objs=self.scene.draw(self)
def round_rect(x, y, w, h, radius=25):
    return [x+radius, y,
            x+radius, y,
            (x+w)-radius, y,
            (x+w)-radius, y,
            (x+w), y,
            (x+w), y+radius,
            (x+w), y+radius,
            (x+w), (y+h)-radius,
            (x+w), (y+h)-radius,
            (x+w), (y+h),
            (x+w)-radius, (y+h),
            (x+w)-radius, (y+h),
            x+radius, (y+h),
            x+radius, (y+h),
            x, (y+h),
            x, (y+h)-radius,
            x, (y+h)-radius,
            x, y+radius,
            x, y+radius,
            x, y]
def get_object(pro,type):
    if type in pro["objects"]:
        return deepcopy(dict(get_json(pro["objects"][type])))
    elif type in pro["compiled objects"]:
        return deepcopy(dict(pro["compiled objects"][type]))
class Scene:
    def __init__(self) -> None:
        self.layers=[]
        self.connections=[]
        self.objects=[]
        self.objs_e={}
        self.objs_old_pos={}
    def json(self):
        return {"layers":self.layers,"objects":self.objects,"connections":self.connections}
    def load(self,path:str):
        js=get_json(path+".scene")
        self.layers=js["layers"]
        self.connections=js["connections"]
        self.objects=js["objects"]
    def save(self,path):
        f=open(path+".scene","w")
        f.seek(0)
        f.write(json.dumps(self.json()))
        f.close()
    def get_Object(self,bid:str)->dict:
        for o in self.objects:
            if o["bid"]==bid:
                return o
    def get_Object2(self,bid:str)->dict:
        for o in range(len(self.objects)):
            if self.objects[o]["bid"]==bid:
                return o
    def deleteBlock(self,select,obj):
        o=self.get_Object2(obj)
        if obj==select["input object"]:
            select["input object"]=None
        if obj==select["output object"]:
            select["output object"]=None
        if obj in select["object move"]:
            select["object move"].remove(obj)
        if obj in select["select object"]:
            select["select object"].remove(obj)
        if obj in self.objs_old_pos:
            self.objs_old_pos.pop(obj)
        self.objects.pop(o)
        i=0
        while i<len(self.connections):
            c=self.connections[i]
            if c["input block"]==obj or c["output block"]==obj:
                self.connections.pop(i)
                i-=1
            i+=1
    def getId(self):
        uuid=str(uuid1())
        o=self.get_Object(uuid)
        while o!=None:
            uuid=str(uuid1())
            o=self.get_Object(uuid)
        return uuid
    def add_object(self,layer:str,pos:list,type:str,pro:dict):
        obj=get_object(pro,type)
        if obj==None:
            return
        obj.setdefault("type",type)
        obj.setdefault("layer",layer)
        obj.setdefault("position",pos)
        obj.setdefault("bid",self.getId())
        obj.pop("inputs")
        obj.pop("outputs")
        obj.pop("editor draw")
        self.objects.append(obj)
    def remove_layer(self,layer:str,select=None):
            self.layers.pop(layer)
            i=0
            while i<len(self.objects):
                if self.objects[i]["layer"]==layer:
                    self.deleteBlock(select,self.objects[i]["bid"])
                    continue
                i+=1
    def get_objects_orden(self,select):
        re=[]
        for l in self.layers:
            for obj in range(len(self.objects)):
                if self.objects[obj]["layer"]==l:
                    re.append(obj)
        obj=0
        while obj < len(self.objects):
            if not obj in re:
                self.deleteBlock(select,self.objects[obj]["bid"])
                continue
            obj+=1
        return re
    def update(self):
        re={"move":[]}
        for objI in self.objects:
            if objI["bid"] in self.objs_old_pos:
                if objI["position"]!=self.objs_old_pos[objI["bid"]]:
                    re["move"].append(objI["bid"])
                    self.objs_old_pos[objI["bid"]]=list(objI["position"])
            else:
                self.objs_old_pos.setdefault(objI["bid"],list(objI["position"]))
        return re
    def draw(self,sceneEditor:SceneEditor):
        sceneEditor.canvas.delete(ALL)
        def clickInput(e,item):
            if sceneEditor.select["input"]==None:
                sceneEditor.select["input"]=item["input"]
                sceneEditor.select["input object"]=item["objI"]["bid"]
                x,y=item["pos"][0]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),item["pos"][1]*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale)
                sceneEditor.select["input draw"]=sceneEditor.canvas.create_oval(x-(20*sceneEditor.imscale),y-(20*sceneEditor.imscale),x+(20*sceneEditor.imscale),y+(20*sceneEditor.imscale),fill="",outline=item["color"],width=5)
                if sceneEditor.select["input"]!=None and sceneEditor.select["output"]!=None:
                    act1=get_object(sceneEditor.pro,self.get_Object(sceneEditor.select["input object"])["type"])["inputs"][sceneEditor.select["input"]]["accept types"]
                    act2=get_object(sceneEditor.pro,self.get_Object(sceneEditor.select["output object"])["type"])["outputs"][sceneEditor.select["output"]]["accept types"]
                    ok=False
                    if act2!=None and act1!=None:
                        for t in act2:
                            if t in act1:
                                ok=True
                                break
                    if (act2==None or act1==None)or ok:
                        oc=None
                        for i,cc in enumerate(self.connections):
                            if cc["input block"]==sceneEditor.select["input object"] and cc["output block"]==sceneEditor.select["output object"] and cc["output"]==sceneEditor.select["output"] and cc["input"]==sceneEditor.select["input"]:
                                oc=i
                                continue
                        if oc==None:
                            self.connections.append({"input block":sceneEditor.select["input object"],"input":sceneEditor.select["input"],"output block":sceneEditor.select["output object"],"output":sceneEditor.select["output"]})
                            sceneEditor.select["input"]=None
                            sceneEditor.select["input object"]=None
                            sceneEditor.select["input draw"]=None
                            sceneEditor.select["output"]=None
                            sceneEditor.select["output object"]=None
                            sceneEditor.select["output draw"]=None
                            re[0]=self.draw(sceneEditor)
                            return
                        else:
                            sceneEditor.select["input"]=None
                            sceneEditor.select["input object"]=None
                            sceneEditor.select["input draw"]=None
                            sceneEditor.select["output"]=None
                            sceneEditor.select["output object"]=None
                            sceneEditor.select["output draw"]=None
                            self.connections.pop(oc)
                            re[0]=self.draw(sceneEditor)
                            return
            else:
                sceneEditor.select["input"]=None
                sceneEditor.select["input object"]=None
                sceneEditor.canvas.delete(sceneEditor.select["input draw"])
                sceneEditor.select["input draw"]=None
        def lReInput(obj):
            return lambda e:clickInput(e,obj)
        def clickOutput(e,item):
            if sceneEditor.select["output"]==None:
                sceneEditor.select["output"]=item["output"]
                sceneEditor.select["output object"]=item["objI"]["bid"]
                x,y=item["pos"][0]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),item["pos"][1]*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale)
                sceneEditor.select["output draw"]=sceneEditor.canvas.create_oval(x-(20*sceneEditor.imscale),y-(20*sceneEditor.imscale),x+(20*sceneEditor.imscale),y+(20*sceneEditor.imscale),fill="",outline=item["color"],width=5)
                if sceneEditor.select["input"]!=None and sceneEditor.select["output"]!=None:
                    act1=get_object(sceneEditor.pro,self.get_Object(sceneEditor.select["input object"])["type"])["inputs"][sceneEditor.select["input"]]["accept types"]
                    act2=get_object(sceneEditor.pro,self.get_Object(sceneEditor.select["output object"])["type"])["outputs"][sceneEditor.select["output"]]["accept types"]
                    ok=False
                    if act2!=None and act1!=None:
                        for t in act2:
                            if t in act1:
                                ok=True
                                break
                    if (act2==None or act1==None)or ok:
                        oc=None
                        for i,cc in enumerate(self.connections):
                            if cc["input block"]==sceneEditor.select["input object"] and cc["output block"]==sceneEditor.select["output object"] and cc["output"]==sceneEditor.select["output"] and cc["input"]==sceneEditor.select["input"]:
                                oc=i
                                continue
                        if oc==None:
                            self.connections.append({"input block":sceneEditor.select["input object"],"input":sceneEditor.select["input"],"output block":sceneEditor.select["output object"],"output":sceneEditor.select["output"]})
                            sceneEditor.select["input"]=None
                            sceneEditor.select["input object"]=None
                            sceneEditor.select["input draw"]=None
                            sceneEditor.select["output"]=None
                            sceneEditor.select["output object"]=None
                            sceneEditor.select["output draw"]=None
                            re[0]=self.draw(sceneEditor)
                            return
                        else:
                            sceneEditor.select["input"]=None
                            sceneEditor.select["input object"]=None
                            sceneEditor.select["input draw"]=None
                            sceneEditor.select["output"]=None
                            sceneEditor.select["output object"]=None
                            sceneEditor.select["output draw"]=None
                            self.connections.pop(oc)
                            re[0]=self.draw(sceneEditor)
                            return
            else:
                sceneEditor.select["output"]=None
                sceneEditor.select["output object"]=None
                sceneEditor.canvas.delete(sceneEditor.select["output draw"])
                sceneEditor.select["output draw"]=None
        def lReOutput(obj):
            return lambda e:clickOutput(e,obj)
        def clickBlock(e,obj):
            if sceneEditor.select["input"]==None:
                if sceneEditor.collide_box==None:
                    if not obj in sceneEditor.select["object move"]:
                        if len(sceneEditor.select["select object"])>1:
                            sceneEditor.select["object move"]=list(sceneEditor.select["select object"])
                        else:
                            sceneEditor.select["object move"].append(obj)
                    if not sceneEditor.shift and len(sceneEditor.select["object move"])<2:
                        sceneEditor.select["select object"]=[]
                    sceneEditor.select["recent add"].append(obj)
                    if not obj in sceneEditor.select["select object"]:
                        sceneEditor.select["select object"].append(obj)
                        re[0]=self.draw(sceneEditor)
            elif get_object(sceneEditor.pro,self.get_Object(sceneEditor.select["input object"])["type"])["inputs"][sceneEditor.select["input"]]["accept types"]==None or "GameObject" in get_object(sceneEditor.pro,self.get_Object(sceneEditor.select["input object"])["type"])["inputs"][sceneEditor.select["input"]]["accept types"]:
                oc=None
                for i,cc in enumerate(self.connections):
                    if cc["input block"]==sceneEditor.select["input object"] and cc["output block"]==obj and cc["input"]==sceneEditor.select["input"] and not "output" in cc:
                        oc=int(i)
                        continue
                if oc==None:
                    sceneEditor.select["output object"]=obj
                    self.connections.append({"input block":sceneEditor.select["input object"],"input":sceneEditor.select["input"],"output block":sceneEditor.select["output object"]})
                    sceneEditor.select["input"]=None
                    sceneEditor.select["input object"]=None
                    sceneEditor.select["input draw"]=None
                    sceneEditor.select["output"]=None
                    sceneEditor.select["output object"]=None
                    sceneEditor.select["output draw"]=None
                else:
                    sceneEditor.select["input"]=None
                    sceneEditor.select["input object"]=None
                    sceneEditor.select["input draw"]=None
                    sceneEditor.select["output"]=None
                    sceneEditor.select["output object"]=None
                    sceneEditor.select["output draw"]=None
                    self.connections.pop(oc)
                re[0]=self.draw(sceneEditor)
                return
        def lReBlock(obj):
            return lambda e:clickBlock(e,obj)
        def After(oo2,p):
            oo=self.get_Object2(oo2)
            if oo!=None:
                self.objects[oo]["parameters"][p]=self.objs_e[oo2][p][1].get()
                if self.objs_e[oo2][p][0]=="text":
                    self.objs_e[oo2][p][1].after(500,lambda:After(oo2,p))
                elif self.objs_e[oo2][p][0]=="options":
                    self.objs_e[oo2][p][1].after(500,lambda:After(oo2,p))
            else:
                self.objs_e.pop(oo2)
        def lReAfter(oo2,p):
            return lambda: After(oo2,p)
        objects=self.get_objects_orden(sceneEditor.select)
        ovals=[]
        for objI in self.objects:
            obj=get_object(sceneEditor.pro,objI["type"])
            if obj==None:
                continue
            for inpt in obj["inputs"]:
                pos2=[objI["position"][0],objI["position"][1]]
                pos3=list(pos2)
                anchor="nw"
                if obj["inputs"][inpt]["dire"]==0:
                    pos2[1]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]-0.1,pos2[1]+0.05]
                    anchor="ne"
                elif obj["inputs"][inpt]["dire"]==1:
                    pos2[0]+=obj["scale"][0]
                    pos2[1]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.05]
                elif obj["inputs"][inpt]["dire"]==2:
                    pos2[0]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.15,pos2[1]-0.1]
                    anchor="sw"
                elif obj["inputs"][inpt]["dire"]==3:
                    pos2[1]+=obj["scale"][1]
                    pos2[0]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.1]
                color="#fff"
                if obj["inputs"][inpt]["accept types"]!=None:
                    if len(obj["inputs"][inpt]["accept types"])>0:
                        color=sceneEditor.pro["types"][obj["inputs"][inpt]["accept types"][0]]["color"]
                x,y=pos2[0]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),pos2[1]*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale)
                o=sceneEditor.canvas.create_oval(x-(13*sceneEditor.imscale),y-(13*sceneEditor.imscale),x+(13*sceneEditor.imscale),y+(10*sceneEditor.imscale),width=3,fill=color)
                sceneEditor.canvas.tag_bind(o,"<Button-1>",lReInput({"color":color,"pos":pos2,"input":inpt,"objI":objI}))
                x2,y2=pos3[0]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),pos3[1]*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale)
                ft=list(sceneEditor.blocks_font)
                ft[1]*=sceneEditor.imscale
                ft[1]=int(ft[1])
                if objI["bid"] in sceneEditor.select["select object"]:
                    sceneEditor.canvas.create_text(x2,y2,font=ft,fill="#000",text=inpt,anchor=anchor)
                if sceneEditor.select["input object"]==objI['bid'] and sceneEditor.select["input"]==inpt:
                    ovals.append([x-(20*sceneEditor.imscale),y-(20*sceneEditor.imscale),x+(20*sceneEditor.imscale),y+(20*sceneEditor.imscale),color,"input draw"])
            for output in obj["outputs"]:
                pos2=[objI["position"][0],objI["position"][1]]
                pos3=list(pos2)
                anchor="nw"
                if obj["outputs"][output]["dire"]==0:
                    pos2[1]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]-0.1,pos2[1]+0.05]
                    anchor="ne"
                elif obj["outputs"][output]["dire"]==1:
                    pos2[0]+=obj["scale"][0]
                    pos2[1]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.05]
                elif obj["outputs"][output]["dire"]==2:
                    pos2[0]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.15,pos2[1]-0.1]
                    anchor="sw"
                elif obj["outputs"][output]["dire"]==3:
                    pos2[1]+=obj["scale"][1]
                    pos2[0]+=0.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos3=[pos2[0]+0.1,pos2[1]+0.1]
                color="#fff"
                if obj["outputs"][output]["accept types"]!=None:
                    if len(obj["outputs"][output]["accept types"])>0:
                        color=sceneEditor.pro["types"][obj["outputs"][output]["accept types"][0]]["color"]
                x,y=pos2[0]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),pos2[1]*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale)
                x2,y2=pos3[0]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),pos3[1]*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale)
                o=sceneEditor.canvas.create_oval(x-(13*sceneEditor.imscale),y-(13*sceneEditor.imscale),x+(13*sceneEditor.imscale),y+(13*sceneEditor.imscale),width=3,fill=color)
                ft=list(sceneEditor.blocks_font)
                ft[1]*=sceneEditor.imscale
                ft[1]=math.ceil(ft[1])
                sceneEditor.canvas.tag_bind(o,"<Button-1>",lReOutput({"color":color,"pos":pos2,"output":output,"objI":objI}))
                if objI["bid"] in sceneEditor.select["select object"]:
                    sceneEditor.canvas.create_text(x2,y2,font=ft,fill="#000",text=output,anchor=anchor)
                if sceneEditor.select["output object"]==objI['bid'] and sceneEditor.select["output"]==output:
                    ovals.append([x-(20*sceneEditor.imscale),y-(20*sceneEditor.imscale),x+(20*sceneEditor.imscale),y+(20*sceneEditor.imscale),color,"output draw"])
        re=[{"text":{},"rect":{}}]
        for oo in objects:
            objI=self.objects[oo]
            obj=get_object(sceneEditor.pro,objI["type"])
            if obj==None:
                continue
            scale=obj["scale"]
            pos=objI["position"]
            bb=[pos[0]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),pos[1]*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale),20,20]
            try:
                for code in obj["editor draw"]:
                    code=str(code)
                    c=code.split(" ")
                    if c[0]=="rect":
                        borderradius=0
                        width=3
                        outline="#000"
                        if len(c)>=3:
                            borderradius=float(c[2])
                        if len(c)>=4:
                            width=float(c[3])
                        if len(c)>=5:
                            outline=c[4]
                        o=sceneEditor.canvas.create_polygon(round_rect(pos[0]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),pos[1]*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale),scale[0]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),scale[1]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),borderradius),fill=c[1],smooth=True,width=width,outline=outline)
                        sceneEditor.canvas.tag_bind(o,"<Button-1>",lReBlock(objI["bid"]),add="+")
                        bb2=list(sceneEditor.canvas.bbox(o))
                        if abs(bb2[2])>=abs(bb[2]):
                            bb[2]=float(bb2[2])
                            bb[0]=float(bb2[0])
                        if abs(bb2[3])>=abs(bb[3]):
                            bb[3]=float(bb2[3])
                            bb[1]=float(bb2[1])
                        re[0]["rect"].setdefault(o,objI["bid"])
                    if c[0]=="text":
                        xx=(scale[0]*float(c[1])+pos[0])*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale)
                        yy=(scale[1]*float(c[2])+pos[1])*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale)
                        ft=list(sceneEditor.blocks_font)
                        ft[1]*=sceneEditor.imscale
                        ft[1]=int(ft[1])
                        o=sceneEditor.canvas.create_text(xx,yy,text=code[code.find("text:")+len("text:"):],anchor="center" if "center" in code[:code.find("text:")+len("text:")] else "w",font=ft,fill="#000")
                        sceneEditor.canvas.tag_bind(o,"<Button-1>",lReBlock(objI["bid"]),add="+")
                        bb2=list(sceneEditor.canvas.bbox(o))
                        if abs(bb2[2])>=abs(bb[2]):
                            bb[2]=float(bb2[2])
                            bb[0]=float(bb2[0])
                        if abs(bb2[3])>=abs(bb[3]):
                            bb[3]=float(bb2[3])
                            bb[1]=float(bb2[1])
                        re[0]["text"].setdefault(o,objI["bid"])
            except:
                pass
            if objI["bid"] in sceneEditor.select["select object"]:
                sceneEditor.canvas.create_rectangle(bb,fill="",outline="#fff",width=1,tags="bbox_select1")
            if objI["bid"] in sceneEditor.select["object move"]:
                sceneEditor.canvas.create_rectangle(bb,fill="",outline="#0f0",width=1,tags="bbox_select2")
            if "parameters" in objI:
                paras=objI["parameters"]
                if not objI["bid"] in self.objs_e:
                    self.objs_e.setdefault(objI["bid"],{})
                for p in paras:
                    xx=((scale[0]*0.45)+pos[0])*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale)
                    yy=(scale[1]*0.5+pos[1])*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale)
                    if "parameters config" in obj and p in obj["parameters config"]:    
                        if obj["parameters config"][p]["type"]=="options":
                            if not p in self.objs_e[objI["bid"]]:
                                om=Combobox(sceneEditor.canvas,values=obj["parameters config"][p]["values"],state="readonly",width=6)
                                om.set(objI["parameters"][p])
                                self.objs_e[objI["bid"]].setdefault(p,["options",om])
                                self.objs_e[objI["bid"]][p][1].after(500,lReAfter(objI["bid"],p))
                            sceneEditor.canvas.create_window(xx,yy,window=self.objs_e[objI["bid"]][p][1],anchor="w")
                    else:
                        if not p in self.objs_e[objI["bid"]]:
                            self.objs_e[objI["bid"]].setdefault(p,["text",Entry(sceneEditor.canvas,font=("Arial",13),background="#000",foreground="#fff",width=4)])
                            self.objs_e[objI["bid"]][p][1].insert(0,objI["parameters"][p])
                            self.objs_e[objI["bid"]][p][1].after(500,lReAfter(objI["bid"],p))
                        sceneEditor.canvas.create_window(xx,yy,window=self.objs_e[objI["bid"]][p][1],anchor="w")
                    #canvas.create_text(xx,yy,text=paras[p],fill="#000",font=engine.blocks_font)
        for c in self.connections:

            inpt=c["input"]
            input_block=c["input block"]
            co=False
            if "output" in c:
                output=c["output"]
            else:
                co=True
            output_block=c["output block"]
            obj=get_object(sceneEditor.pro,self.get_Object(output_block)["type"])
            pos=[self.get_Object(output_block)["position"][0],self.get_Object(output_block)["position"][1]]
            if not co:
                if obj["outputs"][output]["dire"]==0:
                    pos[1]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos[0]-=0.13
                elif obj["outputs"][output]["dire"]==1:
                    pos[0]+=obj["scale"][0]+0.13
                    pos[1]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                elif obj["outputs"][output]["dire"]==2:
                    pos[0]+=.4*(obj["outputs"][output]["pos"]+1)-0.15
                    pos[1]-=0.13
                elif obj["outputs"][output]["dire"]==3:
                    pos[1]+=obj["scale"][1]+0.13
                    pos[0]+=0.4*(obj["outputs"][output]["pos"]+1)-0.15
            objI=dict(obj)
            obj=get_object(sceneEditor.pro,self.get_Object(input_block)["type"])
            pos2=[self.get_Object(input_block)["position"][0],self.get_Object(input_block)["position"][1]]
            if obj["inputs"][inpt]["dire"]==0:
                pos2[1]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                pos2[0]-=0.13
            elif obj["inputs"][inpt]["dire"]==1:
                pos2[0]+=obj["scale"][0]+0.13
                pos2[1]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
            elif obj["inputs"][inpt]["dire"]==2:
                pos2[0]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
                pos2[1]-=0.13
            elif obj["inputs"][inpt]["dire"]==3:
                pos2[1]+=obj["scale"][1]+0.13
                pos2[0]+=0.4*(obj["inputs"][inpt]["pos"]+1)-0.15
            color="#fff"
            if co:
                if obj["inputs"][inpt]["accept types"]!=None:
                    if len(obj["inputs"][inpt]["accept types"])>0:
                        color=sceneEditor.pro["types"][obj["inputs"][inpt]["accept types"][0]]["color"]
            else:
                if objI["outputs"][output]["accept types"]!=None:
                    if len(objI["outputs"][output]["accept types"])>0:
                        color=sceneEditor.pro["types"][objI["outputs"][output]["accept types"][0]]["color"]

            sceneEditor.canvas.create_line(pos[0]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),pos[1]*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale),pos2[0]*(sceneEditor.pro["metter size"][0]*sceneEditor.imscale),pos2[1]*(sceneEditor.pro["metter size"][1]*sceneEditor.imscale),fill=color,width=int(3*sceneEditor.imscale))
        for o in ovals:
            sceneEditor.select[o[5]]=sceneEditor.canvas.create_oval(o[0],o[1],o[2],o[3],outline=o[4],fill="",width=5)
        if sceneEditor.collide_box!=None:
            sceneEditor.collide_box[4]=sceneEditor.canvas.create_rectangle(sceneEditor.collide_box[0],sceneEditor.collide_box[1],sceneEditor.collide_box[2],sceneEditor.collide_box[3],outline="#fff",fill="")
        return re[0]
if __name__=="__main__":
    print("adimin permition request")
    e=Engine()
    e.run()